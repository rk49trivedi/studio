import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-black/80 backdrop-blur-lg' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-6 lg:px-24">
        <nav className="flex items-center justify-between py-6">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img
              src="https://api.builder.io/api/v1/image/assets/TEMP/5fd37d7515be1fc88b4410e9a4983ff71fed5731"
              alt="SpanishLingo Studios"
              className="h-12 w-auto"
            />
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-12">
            <button
              onClick={() => scrollToSection('mixes')}
              className="text-white text-sm font-aeonik uppercase hover:text-brand-red transition-colors"
            >
              Mix Playlist
            </button>
            <button
              onClick={() => scrollToSection('mission')}
              className="text-white text-sm font-aeonik uppercase hover:text-brand-red transition-colors"
            >
              Our Mission
            </button>
            <button
              onClick={() => scrollToSection('opportunities')}
              className="text-white text-sm font-aeonik uppercase hover:text-brand-red transition-colors"
            >
              Opportunities
            </button>
            <button
              onClick={() => scrollToSection('founder')}
              className="text-white text-sm font-aeonik uppercase hover:text-brand-red transition-colors"
            >
              Founder
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="text-white text-sm font-aeonik uppercase hover:text-brand-red transition-colors border-b-2 border-white pb-1"
            >
              Contact
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden text-white p-2"
            aria-label="Toggle menu"
          >
            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 40 36">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1}
                d={isMenuOpen ? "M6 18L34 18M6 6L34 6M6 30L34 30" : "M6 18h28M6 6h28M6 30h28"}
              />
            </svg>
          </button>
        </nav>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden pb-6 border-t border-white/10 pt-6 mt-2"
          >
            <div className="flex flex-col gap-6">
              <button
                onClick={() => scrollToSection('mixes')}
                className="text-white text-lg font-aeonik uppercase hover:text-brand-red transition-colors text-left py-2 border-b border-white/5 hover:border-brand-red"
              >
                Mix Playlist
              </button>
              <button
                onClick={() => scrollToSection('mission')}
                className="text-white text-lg font-aeonik uppercase hover:text-brand-red transition-colors text-left py-2 border-b border-white/5 hover:border-brand-red"
              >
                Our Mission
              </button>
              <button
                onClick={() => scrollToSection('opportunities')}
                className="text-white text-lg font-aeonik uppercase hover:text-brand-red transition-colors text-left py-2 border-b border-white/5 hover:border-brand-red"
              >
                Opportunities
              </button>
              <button
                onClick={() => scrollToSection('founder')}
                className="text-white text-lg font-aeonik uppercase hover:text-brand-red transition-colors text-left py-2 border-b border-white/5 hover:border-brand-red"
              >
                Founder
              </button>
              <button
                onClick={() => scrollToSection('contact')}
                className="text-white text-lg font-aeonik uppercase hover:text-brand-red transition-colors text-left py-2 border-b-2 border-brand-red"
              >
                Contact
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </motion.header>
  );
}
